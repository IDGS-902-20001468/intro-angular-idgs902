export interface IAlumnosIric {
   matricula:number;
    nombre:string;
    correo:string;
    edad:number;
    foto:string;
}
